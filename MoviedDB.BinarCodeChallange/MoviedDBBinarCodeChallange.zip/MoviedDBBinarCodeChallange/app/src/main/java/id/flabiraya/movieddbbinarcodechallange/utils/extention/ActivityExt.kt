package id.flabiraya.movieddbbinarcodechallange.utils.extention

fun AppCompatActivity.addFragmentToActivity(
    @IdRes containerId: Int, fragment: Fragment,
    addToBackStack: Boolean = true, tag: String = fragment::class.java.simpleName
) {
    supportFragmentManager.beginTransaction().run {
        if (addToBackStack) {
            addToBackStack(tag)
        }
        add(containerId, fragment, tag).commit()
    }
}
