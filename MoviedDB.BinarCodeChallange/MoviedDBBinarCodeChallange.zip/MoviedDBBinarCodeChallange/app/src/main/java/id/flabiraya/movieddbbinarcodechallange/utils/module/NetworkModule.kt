package id.flabiraya.movieddbbinarcodechallange.utils.module

private const val API_KEY_PARAM = "api_key"

fun createAppApi(retrofit: Retrofit): AppApi =
    retrofit.create(AppApi::class.java)

fun createOkHttpClient(): OkHttpClient {
    val client = OkHttpClient().newBuilder()
    client.interceptors()
        .add(Interceptor { chain ->
            var request = chain.request()
            val url = request
                .url()
                .newBuilder()
                .addQueryParameter(API_KEY_PARAM, Constant.API_KEY_VALUE).build()
            request = request.newBuilder().url(url).build()
            chain.proceed(request)
        })
    return client.build()
}

fun createRetrofit(okHttpClient: OkHttpClient): Retrofit = Retrofit.Builder()
    .addCallAdapterFactory(RxJava2CallAdapterFactory.createWithScheduler(Schedulers.io()))
    .addConverterFactory(GsonConverterFactory.create())
    .client(okHttpClient)
    .baseUrl(Constant.BASE_URL).build()

val networkModule = module {
    single { createRetrofit(get()) }
    single { createAppApi(get()) }
    single { createOkHttpClient() }
}