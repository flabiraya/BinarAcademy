package id.flabiraya.movieddbbinarcodechallange.utils

object Constant {
    const val API_KEY_VALUE = "3956f50a726a2f785334c24759b97dc6"
    const val YOUTUBE_API_KEY = "AIzaSyC-uVikEieoLwQXcMUCncShW1rDe41r1D8"
    const val BASE_URL = "https://api.themoviedb.org/3/"
    const val BASE_URL_IMG = "http://image.tmdb.org/t/p/original/"
}