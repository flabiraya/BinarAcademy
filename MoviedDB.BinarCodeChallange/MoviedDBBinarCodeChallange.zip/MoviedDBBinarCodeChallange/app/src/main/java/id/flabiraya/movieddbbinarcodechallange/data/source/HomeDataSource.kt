package id.flabiraya.movieddbbinarcodechallange.data.source

interface HomeDatasource {
    interface Local

    interface Remote {
        fun getPopularMovies(page: Int): Single<Response<PopularResponse>>

        fun getGenres(): Single<Response<GenresReponse>>

        fun getMovieDetails(id: Int):Single<Response<Movie>>
    }
}
