package id.flabiraya.movieddbbinarcodechallange.base

abstract class BaseViewModel : ViewModel() {

    private val _compositeDisposable = CompositeDisposable()

    fun addDisposable(disposable: Disposable) {
        _compositeDisposable.add(disposable)
    }

    override fun onCleared() {
        super.onCleared()
        _compositeDisposable.clear()
    }
}
