package id.flabiraya.movieddbbinarcodechallange.screen.search

import android.arch.lifecycle.ViewModel;

class SearchViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
