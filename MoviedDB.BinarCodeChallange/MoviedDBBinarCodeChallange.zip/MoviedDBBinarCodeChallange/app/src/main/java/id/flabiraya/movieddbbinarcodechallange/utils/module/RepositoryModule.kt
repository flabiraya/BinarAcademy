package id.flabiraya.movieddbbinarcodechallange.utils.module

fun createHomeRemoteDataSource(appApi: AppApi): HomeDatasource.Remote = HomeRemoteDataSource(appApi)

fun createHomeRepository(homeRemoteDataSource: HomeDatasource.Remote): HomeRepository =
    HomeRepository(homeRemoteDataSource)

val repositoryModule = module {
    single { createHomeRepository(get()) }
    single { createHomeRemoteDataSource(get()) }
}