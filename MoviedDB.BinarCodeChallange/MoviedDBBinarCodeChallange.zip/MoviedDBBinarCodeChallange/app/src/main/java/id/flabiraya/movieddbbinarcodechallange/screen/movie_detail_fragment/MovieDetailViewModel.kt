package id.flabiraya.movieddbbinarcodechallange.screen.movie_detail_fragment

import android.arch.lifecycle.ViewModel;

class MovieDetailViewModel(val homeRepository: HomeRepository) : BaseViewModel() {
    val movie: MutableLiveData<Movie> = MutableLiveData()
    val onMessageError = SingleLiveEvent<String>()

    fun getMovieDetails(id: Int) {
        addDisposable(
            homeRepository.getMovieDetails(id)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe { response, error ->
                    response?.let {
                        when (it.isSuccessful) {
                            true -> movie.value = it.body()
                            false -> onMessageError.value = RetrofitException.toHttpError(response).getMessageError()
                        }
                    }
                    error?.let {
                        onMessageError.value = RetrofitException.toUnexpectedError(it).getMessageError()
                    }
                }
        )
    }
}

