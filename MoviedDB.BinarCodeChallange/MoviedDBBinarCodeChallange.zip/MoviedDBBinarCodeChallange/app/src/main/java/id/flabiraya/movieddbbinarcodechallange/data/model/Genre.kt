package id.flabiraya.movieddbbinarcodechallange.data.model

data class Genre(

    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String? = null
)