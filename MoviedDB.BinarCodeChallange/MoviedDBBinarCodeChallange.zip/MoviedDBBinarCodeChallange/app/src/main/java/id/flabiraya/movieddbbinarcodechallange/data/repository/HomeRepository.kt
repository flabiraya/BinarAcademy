package id.flabiraya.movieddbbinarcodechallange.data.repository

class HomeRepository(
    val homeRemoteDataSource: HomeDatasource.Remote
) : HomeDatasource.Remote, HomeDatasource.Local {

    override fun getMovieDetails(id: Int): Single<Response<Movie>> = homeRemoteDataSource.getMovieDetails(id)

    override fun getGenres(): Single<Response<GenresReponse>> = homeRemoteDataSource.getGenres()

    override fun getPopularMovies(page: Int): Single<Response<PopularResponse>> =
        homeRemoteDataSource.getPopularMovies(page)
}