package id.flabiraya.movieddbbinarcodechallange.data.source.remote.response

import id.flabiraya.movieddbbinarcodechallange.data.model.Genre

data class GenresReponse(

    @SerializedName("genres") val genres: List<Genre>
)