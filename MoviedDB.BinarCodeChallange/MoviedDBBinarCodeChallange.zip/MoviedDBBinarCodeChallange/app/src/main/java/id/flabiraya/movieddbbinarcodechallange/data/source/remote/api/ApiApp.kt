package id.flabiraya.movieddbbinarcodechallange.data.source.remote.api

interface AppApi {
    @GET("movie/popular")
    fun getPopularMovies(@Query("page") page: Int): Single<Response<PopularResponse>>

    @GET("movie/{id}")
    fun getMovieDetails(@Path("id") id: Int): Single<Response<Movie>>

    @GET("genre/movie/list")
    fun getGenres(): Single<Response<GenresReponse>>
}