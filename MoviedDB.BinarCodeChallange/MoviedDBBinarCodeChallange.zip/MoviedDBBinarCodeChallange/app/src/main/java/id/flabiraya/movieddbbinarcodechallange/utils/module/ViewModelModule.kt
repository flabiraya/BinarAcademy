package id.flabiraya.movieddbbinarcodechallange.utils.module

val viewModelModule = module {
    viewModel { HomeViewModel(get()) }
    viewModel { MovieDetailViewModel(get()) }
}