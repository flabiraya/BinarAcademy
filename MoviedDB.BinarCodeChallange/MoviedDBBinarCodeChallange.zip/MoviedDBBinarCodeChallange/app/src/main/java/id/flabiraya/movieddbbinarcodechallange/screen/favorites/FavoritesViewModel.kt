package id.flabiraya.movieddbbinarcodechallange.screen.favorites

import android.arch.lifecycle.ViewModel;

class FavoritesViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
